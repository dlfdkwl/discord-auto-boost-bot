import discord
from discord.ext import commands, tasks
from discord import app_commands
from discord.ui import Modal, TextInput, View, Button, Select, LayoutView, Container, TextDisplay, ActionRow
import json
import os
import re
import time
import random
import datetime
import asyncio
import threading
import httpx
import tls_client
import io
import yaml
import requests
import logging
from base64 import b64encode
from threading import Lock, Thread
from typing import Dict, List, Optional, Union
from discord_webhook import DiscordWebhook, DiscordEmbed
from PIL import Image, ImageDraw, ImageFont
from enum import Enum, IntEnum
import logger

def load_config():
    try:
        with open("config/config.yaml", "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception as e:
        print(f"설정 로드 오류: {e}")
        return {}

def save_config(config_data):
    try:
        os.makedirs("config", exist_ok=True)
        with open("config/config.yaml", "w", encoding="utf-8") as f:
            yaml.dump(config_data, f, allow_unicode=True, sort_keys=False)
        return True
    except Exception as e:
        print(f"설정 저장 오류: {e}")
        return False

config = load_config()

def check_permission(user_id: int, member: discord.Member = None) -> bool:
    c = load_config()
    owner_ids = c.get("discord", {}).get("owners_ids", [])
    admin_role_ids = c.get("discord", {}).get("admin_role_ids", [])
    if str(user_id) in [str(oid) for oid in owner_ids]: return True
    if member:
        if member.guild_permissions.administrator: return True
        for role in member.roles:
            if str(role.id) in [str(rid) for rid in admin_role_ids]: return True
    return False

async def send_log(category: str, embed: discord.Embed):
    c = load_config()
    channel_id = c.get("discord", {}).get("log_channels", {}).get(category)
    if channel_id:
        try:
            channel = bot.get_channel(int(channel_id))
            if not channel: channel = await bot.fetch_channel(int(channel_id))
            if channel: await channel.send(embed=embed)
        except: pass

def get_user_balance(user_id: int) -> int:
    try:
        if os.path.exists("data/balances.json"):
            with open("data/balances.json", "r", encoding="utf-8") as f:
                return json.load(f).get(str(user_id), 0)
        return 0
    except: return 0

def set_user_balance(user_id: int, amount: int) -> bool:
    try:
        balances = {}
        if os.path.exists("data/balances.json"):
            with open("data/balances.json", "r", encoding="utf-8") as f:
                balances = json.load(f)
        balances[str(user_id)] = amount
        os.makedirs("data", exist_ok=True)
        with open("data/balances.json", "w", encoding="utf-8") as f:
            json.dump(balances, f, indent=4, ensure_ascii=False)
        return True
    except: return False

def add_user_balance(user_id: int, amount: int) -> bool:
    return set_user_balance(user_id, get_user_balance(user_id) + amount)

def deduct_user_balance(user_id: int, amount: int) -> bool:
    current = get_user_balance(user_id)
    if current < amount: return False
    return set_user_balance(user_id, current - amount)

def get_stock_count(filename: str) -> int:
    try:
        if not os.path.exists(filename): return 0
        with open(filename, "r", encoding="utf-8") as f:
            return len([line for line in f if line.strip()])
    except: return 0

def get_stock_tokens(filename: str) -> list:
    tokens = []
    try:
        if not os.path.exists(filename): return []
        with open(filename, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line: continue
                if ":" in line:
                    parts = line.split(":")
                    tokens.append(parts[2] if len(parts) >= 3 else parts[1] if len(parts) == 2 else line)
                else: tokens.append(line)
    except: pass
    return tokens

def remove_token(token: str, filename: str):
    try:
        if not os.path.exists(filename): return
        with open(filename, "r", encoding="utf-8") as f:
            lines = f.readlines()
        with open(filename, "w", encoding="utf-8") as f:
            for line in lines:
                if token not in line: f.write(line)
    except: pass

def get_invite_code(inv):
    if "discord.gg/" in inv: return inv.split("discord.gg/")[1]
    if "discord.com/invite/" in inv: return inv.split("discord.com/invite/")[1]
    return inv

def check_invite(invite: str):
    try:
        r = requests.get(f"https://discord.com/api/v9/invites/{invite}?with_counts=true").json()
        if r.get("code") == 10006: return False
        return r.get("guild", {}).get("id")
    except: return False

def create_boost_status_image(total_boosts: int) -> io.BytesIO:
    width, height = 700, 250
    img = Image.new('RGB', (width, height), color=(20, 20, 25))
    draw = ImageDraw.Draw(img)
    padding, corner_radius = 40, 30
    box_x1, box_y1, box_x2, box_y2 = padding, padding, width - padding, height - padding
    mask = Image.new('L', (width, height), 0)
    mask_draw = ImageDraw.Draw(mask)
    try: mask_draw.rounded_rectangle([(box_x1, box_y1), (box_x2, box_y2)], radius=corner_radius, fill=255)
    except: mask_draw.rectangle([(box_x1, box_y1), (box_x2, box_y2)], fill=255)
    gradient_layer = Image.new('RGB', (width, height), color=(0, 0, 0))
    gradient_draw = ImageDraw.Draw(gradient_layer)
    box_height = box_y2 - box_y1
    for y in range(box_y1, box_y2):
        ratio = (y - box_y1) / box_height if box_height > 0 else 0
        r, g, b = int(139 + (236 - 139) * ratio), int(92 + (72 - 92) * ratio), int(246 + (153 - 246) * ratio)
        gradient_draw.rectangle([(box_x1, y), (box_x2, y + 1)], fill=(r, g, b))
    img.paste(gradient_layer, (0, 0), mask)
    font_paths = ["C:/Windows/Fonts/malgun.ttf", "C:/Windows/Fonts/gulim.ttc", "arial.ttf"]
    def get_font(size):
        for p in font_paths:
            try: return ImageFont.truetype(p, size)
            except: continue
        return ImageFont.load_default()
    num_font, label_font = get_font(120), get_font(22)
    num_text, label_text = str(total_boosts), "남은 부스트 현황"
    nb, lb = draw.textbbox((0, 0), num_text, font=num_font), draw.textbbox((0, 0), label_text, font=label_font)
    draw.text(((width-(nb[2]-nb[0]))//2, box_y1+(box_height*0.25)-((nb[3]-nb[1])//2)), num_text, font=num_font, fill=(255, 255, 255))
    draw.text(((width-(lb[2]-lb[0]))//2, box_y2-(lb[3]-lb[1])-20), label_text, font=label_font, fill=(255, 255, 255))
    img_bytes = io.BytesIO()
    img.save(img_bytes, format='PNG')
    img_bytes.seek(0)
    return img_bytes

def save_panel_message(channel_id: int, message_id: int):
    try:
        data = {"channel_id": channel_id, "message_id": message_id}
        os.makedirs("data", exist_ok=True)
        with open("data/panel_info.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
    except: pass

def get_panel_info():
    try:
        if os.path.exists("data/panel_info.json"):
            with open("data/panel_info.json", "r", encoding="utf-8") as f:
                return json.load(f)
    except: pass
    return None

PENDING_CHARGES_FILE = "data/pending_charges.json"

def _load_pending_charges():
    try:
        os.makedirs("data", exist_ok=True)
        if os.path.exists(PENDING_CHARGES_FILE):
            with open(PENDING_CHARGES_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {"pending": []}

def _save_pending_charges(data):
    try:
        with open(PENDING_CHARGES_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception:
        pass

def save_pending_charge(user_id: int, depositor: str, amount: int, channel_id: int, message_id: int) -> str:
    data = _load_pending_charges()
    pid = f"{user_id}_{channel_id}_{message_id}_{int(time.time())}"
    data["pending"].append({
        "id": pid,
        "user_id": user_id,
        "depositor": depositor.strip(),
        "amount": amount,
        "channel_id": channel_id,
        "message_id": message_id,
        "created_at": datetime.datetime.now().isoformat(),
    })
    _save_pending_charges(data)
    return pid

def find_pending_charge(depositor: str, amount: int):
    data = _load_pending_charges()
    depositor = str(depositor or "").strip()
    for p in data["pending"]:
        if p.get("depositor") == depositor and int(p.get("amount", 0)) == int(amount):
            return (
                p["id"],
                int(p["user_id"]),
                p["depositor"],
                int(p["amount"]),
                int(p["channel_id"]),
                int(p["message_id"]),
            )
    return None

def mark_pending_charge_done(pending_id: str):
    data = _load_pending_charges()
    data["pending"] = [p for p in data["pending"] if p.get("id") != pending_id]
    _save_pending_charges(data)

def result_layout(text: str, _button_label: str = "확인"):
    """단순 안내/결과 메시지용 LayoutView (TextDisplay만, 버튼 없음)."""
    class ResultLayout(LayoutView):
        def __init__(self):
            super().__init__(timeout=120)
            self.container = Container(TextDisplay(text))
            self.add_item(self.container)

        async def interaction_check(self, i: discord.Interaction) -> bool:
            return True
    return ResultLayout()


def build_charge_waiting_view(depositor: str, amount: int):
    """채널에 보낼 '입금 대기 중' 메시지용 LayoutView. 충전 완료 시 이 메시지를 수정해 '충전완료'로 바꾼다."""
    class ChargeWaitingLayout(LayoutView):
        def __init__(self):
            super().__init__(timeout=None)
            self.container = Container(
                TextDisplay(f"**# 입금 대기 중**\n\n**입금자명:** {depositor}\n**금액:** {amount:,}원\n\n입금 완료 시 자동으로 충전됩니다."),
            )
            self.add_item(self.container)
    return ChargeWaitingLayout()

def build_charge_completed_view(depositor: str, amount: int, balance: int):
    """입금 대기 메시지를 '충전완료'로 수정할 때 쓸 LayoutView."""
    class ChargeCompletedLayout(LayoutView):
        def __init__(self):
            super().__init__(timeout=None)
            self.container = Container(
                TextDisplay(
                    f"**# 충전완료**\n\n"
                    f"**입금자명:** {depositor}\n"
                    f"**충전 금액:** `{amount:,}`원\n"
                    f"**현재 잔액:** `{balance:,}`원"
                ),
            )
            self.add_item(self.container)
    return ChargeCompletedLayout()

async def update_panel_stock():
    info = get_panel_info()
    if not info: return
    try:
        channel = bot.get_channel(info["channel_id"])
        if not channel: channel = await bot.fetch_channel(info["channel_id"])
        message = await channel.fetch_message(info["message_id"])
        s1, s3 = get_stock_count("data/1m.txt"), get_stock_count("data/3m.txt")
        img_bytes = create_boost_status_image((s1 + s3) * 2)
        file = discord.File(img_bytes, filename="status.png")
        await message.edit(attachments=[file])
    except: pass

def save_purchase_history(user_id: int, product: str, months: int, amount: int, price: int, invite: str, success_count: int, failed_count: int, time_taken: float):
    history_file = "data/purchase_history.json"
    try:
        history = []
        if os.path.exists(history_file):
            with open(history_file, "r", encoding="utf-8") as f: history = json.load(f)
        purchase_record = {"user_id": str(user_id), "product": product, "months": months, "amount": amount, "price": price, "invite": invite, "success_count": success_count, "failed_count": failed_count, "time_taken": time_taken, "timestamp": datetime.datetime.now().isoformat()}
        history.append(purchase_record)
        os.makedirs("data", exist_ok=True)
        with open(history_file, "w", encoding="utf-8") as f: json.dump(history, f, indent=4, ensure_ascii=False)
        return True
    except: return False

def save_review(user_id: int, rating: int, content: str, purchase_id: str = None) -> bool:
    review_file = "data/reviews.json"
    try:
        reviews = []
        if os.path.exists(review_file):
            with open(review_file, "r", encoding="utf-8") as f: reviews = json.load(f)
        review_record = {"user_id": str(user_id), "rating": rating, "content": content, "purchase_id": purchase_id, "timestamp": datetime.datetime.now().isoformat()}
        reviews.append(review_record)
        os.makedirs("data", exist_ok=True)
        with open(review_file, "w", encoding="utf-8") as f: json.dump(reviews, f, indent=4, ensure_ascii=False)
        return True
    except: return False

def get_reviews(limit: int = 10) -> list:
    try:
        if os.path.exists("data/reviews.json"):
            with open("data/reviews.json", "r", encoding="utf-8") as f:
                reviews = json.load(f)
                return sorted(reviews, key=lambda x: x.get("timestamp", ""), reverse=True)[:limit]
        return []
    except: return []


intents = discord.Intents.all()
bot = commands.Bot(command_prefix="/", intents=intents)


class Booster:
    def __init__(self, session_folder=None):
        self.session_folder = session_folder or "sessions"
        os.makedirs(self.session_folder, exist_ok=True)
        self.crome_v = f'Chrome_{str(random.randint(110, 118))}'
        self.useragent = f'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) {self.crome_v}.0.0.0 Safari/537.36'
        self.client = tls_client.Session(client_identifier=self.crome_v, random_tls_extension_order=True)
        self.success, self.failed, self.captcha = [], [], []
        self.fp, self.ckis, self.x, self.guild_id = "", "", "", ""
        self.setup_headers()

    def setup_headers(self):
        properties = {"os": 'Windows', "browser": 'Chrome', "device": "", "system_locale": "ko-KR", "browser_user_agent": self.useragent, "browser_version": f'{self.crome_v}.0.0.0', "os_version": "10", "referrer": "", "referring_domain": "", "referrer_current": "", "referring_domain_current": "", "release_channel": "stable", "client_build_number": 236850, "client_event_source": None}
        self.x = b64encode(json.dumps(properties, separators=(',', ':')).encode("utf-8")).decode()
        try:
            r = httpx.get('https://discord.com/api/v9/experiments', headers={"User-Agent": self.useragent})
            if r.status_code == 200:
                self.fp = r.json().get('fingerprint', '')
                self.ckis = f'locale=ko-KR; __dcfduid={r.cookies.get("__dcfduid")}; __sdcfduid={r.cookies.get("__sdcfduid")}; __cfruid={r.cookies.get("__cfruid")}; _cfuvid={r.cookies.get("_cfuvid")}'
        except: pass

    def solve_captcha(self, sitekey, url, rqdata=None):
        c = load_config()
        api_key = c.get("extras", {}).get("captcha_solver", {}).get("hcoptcha_api_key")
        if not api_key: 
            print("[DEBUG] Captcha API Key missing in config")
            return None
        try:
            payload = {
                "clientKey": api_key, 
                "task": {
                    "type": "HCaptchaTaskProxyLess", 
                    "websiteURL": url, 
                    "websiteKey": sitekey,
                    "userAgent": self.useragent,
                    "isInvisible": True
                }
            }
            if rqdata: payload["task"]["enterprisePayload"] = {"rqdata": rqdata}
            
            res = requests.post("https://api.capsolver.com/createTask", json=payload).json()
            task_id = res.get("taskId")
            if not task_id: 
                print(f"[DEBUG] Captcha Task Creation Failed: {res}")
                return None
            
            print(f"[DEBUG] Captcha Task Created: {task_id}. Waiting for solution...")
            for _ in range(40):
                time.sleep(3)
                status = requests.post("https://api.capsolver.com/getTaskResult", json={"clientKey": api_key, "taskId": task_id}).json()
                if status.get("status") == "ready": 
                    print("[DEBUG] Captcha Solved Successfully")
                    return status.get("solution", {}).get("gRecaptchaResponse")
                if status.get("status") == "failed":
                    print(f"[DEBUG] Captcha Solving Failed: {status}")
                    break
        except Exception as e: 
            print(f"[DEBUG] Captcha Solver Exception: {e}")
        return None

    def boost(self, token, invite, guild_id):
        tkv = token.split(':')[2] if ':' in str(token) and len(token.split(':')) >= 3 else token
        headers = {
            "authority": "discord.com", 
            "accept": "*/*",
            "accept-language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
            "Authorization": str(tkv), 
            "Content-Type": "application/json", 
            "Cookie": str(self.ckis),
            "origin": "https://discord.com",
            "referer": f"https://discord.com/invite/{invite}",
            "sec-ch-ua": f'"Not_A Brand";v="8", "Chromium";v="{self.crome_v.split("_")[1]}", "Google Chrome";v="{self.crome_v.split("_")[1]}"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "User-Agent": self.useragent, 
            "X-Super-Properties": self.x, 
            "X-fingerprint": self.fp, 
            "X-Discord-Locale": "ko-KR",
            "X-Debug-Options": "bugReporterEnabled"
        }
        try:
            slots = self.client.get("https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots", headers=headers)
            if slots.status_code != 200: 
                print(f"[DEBUG] Slots failed for {token[:10]}... Status: {slots.status_code}")
                self.failed.append(token); return
            slot_json = slots.json()
            if not slot_json: self.failed.append(token); return
            
            join_url = f"https://discord.com/api/v9/invites/{invite}"
            join = self.client.post(join_url, headers=headers, json={})
            if join.status_code != 200:
                print(f"[DEBUG] Join failed for {token[:10]}... Status: {join.status_code}")
                if "captcha" in join.text:
                    self.captcha.append(token)
                    res_json = join.json()
                    sitekey = res_json.get("captcha_sitekey")
                    rqdata = res_json.get("captcha_rqdata")
                    if sitekey:
                        print(f"[DEBUG] Captcha detected (rqdata: {'yes' if rqdata else 'no'}), solving...")
                        solution = self.solve_captcha(sitekey, "https://discord.com", rqdata)
                        if solution:
                            headers["X-Captcha-Key"] = solution
                            if rqdata: headers["X-Captcha-Rqtoken"] = res_json.get("captcha_rqtoken")
                            
                            join = self.client.post(join_url, headers=headers, json={"captcha_key": solution})
                            if join.status_code != 200: 
                                print(f"[DEBUG] Join failed after captcha for {token[:10]}... Status: {join.status_code}")
                                self.failed.append(token); return
                        else: 
                            print(f"[DEBUG] Captcha solution failed for {token[:10]}")
                            self.failed.append(token); return
                else: 
                    print(f"[DEBUG] Join failed (No Captcha) for {token[:10]}: {join.text[:100]}")
                    self.failed.append(token); return
            
            self.guild_id = guild_id
            slot_ids = [s["id"] for s in slot_json]
            r = self.client.put(f"https://discord.com/api/v9/guilds/{guild_id}/premium/subscriptions", headers=headers, json={"user_premium_guild_subscription_slot_ids": slot_ids})
            if r.status_code in [200, 201, 204]: self.success.append(token)
            else: self.failed.append(token)
        except: self.failed.append(token)

    def humanizer(self, token, nickname=None, bio=None):
        tkv = token.split(':')[2] if ':' in str(token) and len(token.split(':')) >= 3 else token
        headers = {"Authorization": str(tkv), "Content-Type": "application/json", "User-Agent": self.useragent, "X-Super-Properties": self.x}
        try:
            if nickname: self.client.patch(f'https://discord.com/api/v9/guilds/{self.guild_id}/members/@me', headers=headers, json={'nick': nickname})
            if bio: self.client.patch('https://discord.com/api/v9/users/@me', headers=headers, json={'bio': bio})
        except: pass

    def thread_boost(self, invite, tokens, guild_id):
        threads = []
        for token in tokens:
            t = threading.Thread(target=self.boost, args=(token, invite, guild_id))
            t.daemon = True; threads.append(t); t.start()
        for t in threads: t.join()
        return {"success": self.success, "failed": self.failed, "captcha": self.captcha}

    def humanizerthread(self, tokens, nickname=None, bio=None):
        threads = []
        for token in tokens:
            t = threading.Thread(target=self.humanizer, args=(token, nickname, bio))
            t.daemon = True; threads.append(t); t.start()
        for t in threads: t.join()

class ReviewModal(Modal, title="후기 작성"):
    rating = TextInput(label="평점 (1-5)", placeholder="1~5 숫자 입력", required=True, max_length=1)
    content = TextInput(label="후기 내용", placeholder="후기를 작성해주세요", required=True, style=discord.TextStyle.paragraph, max_length=500)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            r = int(self.rating.value)
            if not 1 <= r <= 5:
                await interaction.response.send_message(view=result_layout("❌ 평점은 1~5 사이여야 합니다."), ephemeral=True)
                return
            if save_review(interaction.user.id, r, self.content.value):
                embed = discord.Embed(title="⭐ 새로운 후기 등록", description=f"**작성자:** {interaction.user.mention}\n**평점:** {'⭐'*r}\n**내용:** {self.content.value}", color=0x8b5cf6)
                await send_log("review", embed)
                await interaction.response.send_message(view=result_layout("✅ 후기가 등록되었습니다."), ephemeral=True)
        except Exception:
            await interaction.response.send_message(view=result_layout("❌ 평점은 숫자여야 합니다."), ephemeral=True)

class PurchaseModal(Modal, title="부스트 구매"):
    def __init__(self, months, amount, price):
        super().__init__(title=f"{months}개월 {amount}개 구매 ({price:,}원)")
        self.months, self.amount, self.price = months, amount, price
        self.invite = TextInput(label="초대 링크", placeholder="https://discord.gg/...", required=True)
        self.nick = TextInput(label="변경할 닉네임", placeholder="미입력 시 기본값", required=False)
        self.bio = TextInput(label="변경할 소개글", placeholder="미입력 시 기본값", required=False)
        self.add_item(self.invite); self.add_item(self.nick); self.add_item(self.bio)
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        if not deduct_user_balance(interaction.user.id, self.price):
            await interaction.followup.send(view=result_layout("❌ 잔액이 부족합니다."), ephemeral=True)
            return
        invite_code = get_invite_code(self.invite.value)
        guild_id = check_invite(invite_code)
        if not guild_id:
            add_user_balance(interaction.user.id, self.price)
            await interaction.followup.send(view=result_layout("❌ 잘못된 초대 링크입니다."), ephemeral=True)
            return
        filename = f"data/{self.months}m.txt"
        tokens = get_stock_tokens(filename)
        req = self.amount // 2
        if len(tokens) < req:
            add_user_balance(interaction.user.id, self.price)
            await interaction.followup.send(view=result_layout("❌ 재고가 부족합니다."), ephemeral=True)
            return
        use_tokens = tokens[:req]
        for t in use_tokens: remove_token(t, filename)
        booster = Booster()
        start_time = time.time()
        res = booster.thread_boost(invite_code, use_tokens, guild_id)
        c = load_config()
        target_nick = self.nick.value or c.get("customizations", {}).get("nick", "dk")
        target_bio = self.bio.value or c.get("customizations", {}).get("bio", "dk")
        if c.get("customizations", {}).get("enable", True): booster.humanizerthread(res['success'], target_nick, target_bio)
        duration = round(time.time() - start_time, 2)
        
        failed_count = len(res['failed'])
        refund_amount = 0
        if failed_count > 0:
            refund_amount = (self.price // req) * failed_count
            add_user_balance(interaction.user.id, refund_amount)

        save_purchase_history(interaction.user.id, f"{self.months}개월 {self.amount}개", self.months, self.amount, self.price, invite_code, len(res['success']), len(res['failed']), duration)
        
        log_embed = discord.Embed(title="부스트 로그 데이터", color=0x2f3136)
        log_embed.description = (f"**수량** ➔ {self.amount} 부스트\n**개월** ➔ {self.months}개월\n**서버 링크** ➔ .gg/{invite_code}\n**토큰** ➔ {req}\n**성공** ➔ {len(res['success'])*2}\n**실패** ➔ {len(res['failed'])*2}\n**소요 시간** ➔ {duration}초\n\n**실패 / 무효**\n```\n{res['failed'] if res['failed'] else '[]'}\n```\n**캡차**\n```\n{res['captcha'] if res['captcha'] else '[]'}\n```\n**성공**\n```\n{res['success'] if res['success'] else '[]'}\n```\n**기타 정보**\n```\n사용자 ID ➔ {interaction.user.id}\n사용자 멘션 ➔ {interaction.user.name}\n키 ➔ {self.months}m-{interaction.user.id}-{int(time.time())}\n```")
        log_embed.set_footer(text="made by dk")
        

        await send_log("boost", log_embed); await update_panel_stock()
        
        result_msg = f"**✅ 부스트 완료**\n\n**성공:** {len(res['success'])*2}개\n**실패:** {len(res['failed'])*2}개"
        if refund_amount > 0:
            result_msg += f"\n**환불:** {refund_amount:,}원 (잔액으로 환불되었습니다)"
        await interaction.followup.send(view=result_layout(result_msg), ephemeral=True)

        try:
            dm_desc = f"**🎁 구매해주셔서 감사합니다!**\n\n부스트가 완료되었습니다. 아래 내용을 확인해주세요!\n\n**성공:** {len(res['success'])*2}개\n**실패:** {len(res['failed'])*2}개"
            if refund_amount > 0:
                dm_desc += f"\n\n⚠️ **환불 안내**\n부스트 중 {failed_count*2}개가 실패하여 총 **{refund_amount:,}원**이 잔액으로 환불되었습니다."
            dm_desc += "\n\n서비스가 만족스러우셨다면 후기를 작성해주세요!"

            class DMReviewLayout(LayoutView):
                def __init__(self, text: str):
                    super().__init__(timeout=180)
                    self.container = Container(
                        TextDisplay(text),
                        ActionRow(
                            Button(label="후기 작성하기", emoji="⭐", style=discord.ButtonStyle.primary, custom_id="btn_write_review_dm"),
                        ),
                    )
            await interaction.user.send(view=DMReviewLayout(dm_desc))
        except: pass


class BuyLayout(LayoutView):
    """구매 버튼 클릭 시 보여줄 레이아웃(TextDisplay + Select)."""
    def __init__(self, prices_map: dict, options: list):
        super().__init__(timeout=60)
        self.prices_map = prices_map
        sel = Select(placeholder="옵션을 선택하세요", options=options[:25], custom_id="buy_select")
        self.container = Container(
            TextDisplay("**🛒 부스트 구매**\n구매하실 옵션을 선택해주세요."),
            ActionRow(sel),
        )
        self.add_item(self.container)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.data.get("custom_id") != "buy_select":
            return True
        val = (interaction.data.get("values") or [None])[0]
        if not val:
            return True
        parts = val.split("_")
        m = int(parts[0].replace("m", ""))
        a = int(parts[1])
        await interaction.response.send_modal(PurchaseModal(m, a, self.prices_map.get(val, 0)))
        return True


class PanelLayout(LayoutView):
    def __init__(self):
        super().__init__(timeout=None)

    container = Container(
        TextDisplay("**DK 부스트**\n아래 버튼을 눌러 서비스를 이용하세요!"),
        ActionRow(
            Button(label="구매", emoji="🛒", style=discord.ButtonStyle.secondary, custom_id="btn_buy"),
            Button(label="충전", emoji="💰", style=discord.ButtonStyle.secondary, custom_id="btn_recharge"),
            Button(label="내 정보", emoji="👤", style=discord.ButtonStyle.secondary, custom_id="btn_info"),
        )
    )

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        custom_id = interaction.data.get("custom_id")

        if custom_id == "btn_buy":
            await self.handle_buy(interaction)
        elif custom_id == "btn_recharge":
            await self.handle_recharge(interaction)
        elif custom_id == "btn_info":
            await self.handle_info(interaction)

        return True

    async def handle_buy(self, interaction: discord.Interaction):
        c = load_config()
        prices = c.get("payment", {}).get("prices", {})

        if not prices:
            await interaction.response.send_message(view=result_layout("❌ 가격 정보가 설정되지 않았습니다."), ephemeral=True)
            return

        options = []
        for m in [1, 3]:
            for a in [2, 4, 6, 8, 10, 14, 28]:
                key = f"{m}m_{a}"
                price = prices.get(key, 0)
                if price > 0:
                    options.append(discord.SelectOption(label=f"{m}개월 {a}개 ({price:,}원)", value=key))
        if not options:
            await interaction.response.send_message(view=result_layout("❌ 등록된 옵션이 없습니다."), ephemeral=True)
            return

        await interaction.response.send_message(view=BuyLayout(prices, options), ephemeral=True)

    async def handle_recharge(self, interaction: discord.Interaction):
        await interaction.response.send_modal(RechargeModal())

    async def handle_info(self, interaction: discord.Interaction):
        balance = get_user_balance(interaction.user.id)
        text = f"**# 👤 내 정보**\n\n**사용자:** {interaction.user.name}\n**잔액:** {balance:,}원"
        await interaction.response.send_message(view=result_layout(text), ephemeral=True)


@bot.tree.command(name="패널", description="부스트 구매 패널을 전송합니다.")
async def panel(interaction: discord.Interaction):
    if not check_permission(interaction.user.id, interaction.guild.get_member(interaction.user.id)):
        return await interaction.response.send_message(view=result_layout("❌ 권한이 없습니다."), ephemeral=True)

    s1, s3 = get_stock_count("data/1m.txt"), get_stock_count("data/3m.txt")
    img_bytes = create_boost_status_image((s1 + s3) * 2)
    file = discord.File(img_bytes, filename="status.png")
    
    msg = await interaction.channel.send(file=file, view=PanelLayout())
    save_panel_message(interaction.channel.id, msg.id)
    await interaction.response.send_message(view=result_layout("✅ 패널이 전송되었습니다."), ephemeral=True)

@bot.tree.command(name="재고추가", description="니트로 토큰 재고를 추가합니다.")
async def restock(interaction: discord.Interaction, 개월: int, 토큰: str):
    if not check_permission(interaction.user.id, interaction.guild.get_member(interaction.user.id)):
        return await interaction.response.send_message(view=result_layout("❌ 권한이 없습니다."), ephemeral=True)
    if 개월 not in [1, 3]:
        return await interaction.response.send_message(view=result_layout("❌ 개월은 1 또는 3만 가능합니다."), ephemeral=True)
    tokens = [t.strip() for t in 토큰.split("\n") if t.strip()]
    filename = f"data/{개월}m.txt"
    os.makedirs("data", exist_ok=True)
    with open(filename, "a", encoding="utf-8") as f:
        for t in tokens:
            f.write(f"{t}\n")
    await update_panel_stock()
    await interaction.response.send_message(view=result_layout(f"✅ {개월}개월 재고 {len(tokens)}개가 추가되었습니다."), ephemeral=True)

@bot.tree.command(name="재고", description="현재 부스트 재고를 확인합니다.")
async def stock(interaction: discord.Interaction):
    if not check_permission(interaction.user.id, interaction.guild.get_member(interaction.user.id)):
        return await interaction.response.send_message(view=result_layout("❌ 권한이 없습니다."), ephemeral=True)
    s1, s3 = get_stock_count("data/1m.txt"), get_stock_count("data/3m.txt")
    text = f"**# 📦 재고 현황**\n\n**1개월 토큰:** {s1}개 ({s1*2}부스트)\n**3개월 토큰:** {s3}개 ({s3*2}부스트)"
    await interaction.response.send_message(view=result_layout(text), ephemeral=True)


@bot.tree.command(name="가격수정", description="부스트 가격을 수정합니다.")
async def edit_price(interaction: discord.Interaction):
    if not check_permission(interaction.user.id, interaction.guild.get_member(interaction.user.id)):
        return await interaction.response.send_message(view=result_layout("❌ 권한이 없습니다."), ephemeral=True)
    
    class PriceEditModal(Modal):
        def __init__(self, page=1):
            super().__init__(title=f"가격 수정 (페이지 {page}/3)")
            self.page = page
            c = load_config(); p = c.get("payment", {}).get("prices", {})
            if page == 1:
                self.p1m2 = TextInput(label="1개월 2개", default=str(p.get("1m_2", 800)))
                self.p1m4 = TextInput(label="1개월 4개", default=str(p.get("1m_4", 1700)))
                self.p1m6 = TextInput(label="1개월 6개", default=str(p.get("1m_6", 2500)))
                self.p1m8 = TextInput(label="1개월 8개", default=str(p.get("1m_8", 3400)))
                self.p1m10 = TextInput(label="1개월 10개", default=str(p.get("1m_10", 4200)))
                for item in [self.p1m2, self.p1m4, self.p1m6, self.p1m8, self.p1m10]: self.add_item(item)
            elif page == 2:
                self.p1m14 = TextInput(label="1개월 14개", default=str(p.get("1m_14", 5800)))
                self.p1m28 = TextInput(label="1개월 28개", default=str(p.get("1m_28", 11000)))
                self.p3m2 = TextInput(label="3개월 2개", default=str(p.get("3m_2", 2000)))
                self.p3m4 = TextInput(label="3개월 4개", default=str(p.get("3m_4", 4000)))
                self.p3m6 = TextInput(label="3개월 6개", default=str(p.get("3m_6", 6000)))
                for item in [self.p1m14, self.p1m28, self.p3m2, self.p3m4, self.p3m6]: self.add_item(item)
            elif page == 3:
                self.p3m8 = TextInput(label="3개월 8개", default=str(p.get("3m_8", 8000)))
                self.p3m10 = TextInput(label="3개월 10개", default=str(p.get("3m_10", 10000)))
                self.p3m14 = TextInput(label="3개월 14개", default=str(p.get("3m_14", 14000)))
                self.p3m28 = TextInput(label="3개월 28개", default=str(p.get("3m_28", 28000)))
                for item in [self.p3m8, self.p3m10, self.p3m14, self.p3m28]: self.add_item(item)
        async def on_submit(self, i: discord.Interaction):
            c = load_config(); p = c["payment"]["prices"]
            try:
                if self.page == 1:
                    p.update({"1m_2": int(self.p1m2.value), "1m_4": int(self.p1m4.value), "1m_6": int(self.p1m6.value), "1m_8": int(self.p1m8.value), "1m_10": int(self.p1m10.value)})
                elif self.page == 2:
                    p.update({"1m_14": int(self.p1m14.value), "1m_28": int(self.p1m28.value), "3m_2": int(self.p3m2.value), "3m_4": int(self.p3m4.value), "3m_6": int(self.p3m6.value)})
                elif self.page == 3:
                    p.update({"3m_8": int(self.p3m8.value), "3m_10": int(self.p3m10.value), "3m_14": int(self.p3m14.value), "3m_28": int(self.p3m28.value)})
                if save_config(c):
                    await i.response.send_message(view=result_layout(f"✅ 페이지 {self.page} 가격이 수정되었습니다."), ephemeral=True)
            except Exception:
                await i.response.send_message(view=result_layout("❌ 올바른 숫자를 입력해주세요."), ephemeral=True)
    
    class PricePageLayout(LayoutView):
        def __init__(self):
            super().__init__(timeout=120)

        container = Container(
            TextDisplay("수정할 가격 페이지를 선택하세요."),
            ActionRow(
                Button(label="페이지 1 (1개월 2~10개)", style=discord.ButtonStyle.primary, custom_id="price_p1"),
                Button(label="페이지 2 (1개월 14~28, 3개월 2~6)", style=discord.ButtonStyle.primary, custom_id="price_p2"),
                Button(label="페이지 3 (3개월 8~28개)", style=discord.ButtonStyle.primary, custom_id="price_p3"),
            ),
        )

        async def interaction_check(self, i: discord.Interaction) -> bool:
            cid = i.data.get("custom_id")
            if cid == "price_p1":
                await i.response.send_modal(PriceEditModal(1))
            elif cid == "price_p2":
                await i.response.send_modal(PriceEditModal(2))
            elif cid == "price_p3":
                await i.response.send_modal(PriceEditModal(3))
            return True

    await interaction.response.send_message(view=PricePageLayout(), ephemeral=True)

@bot.tree.command(name="설정", description="봇 설정을 변경합니다.")
async def settings(interaction: discord.Interaction):
    if not check_permission(interaction.user.id, interaction.guild.get_member(interaction.user.id)):
        return await interaction.response.send_message(view=result_layout("❌ 권한이 없습니다."), ephemeral=True)
    class SettingsLayout(LayoutView):
        def __init__(self):
            super().__init__(timeout=120)

        container = Container(
            TextDisplay("변경할 설정을 선택하세요."),
            ActionRow(
                Button(label="로그 채널 설정", style=discord.ButtonStyle.secondary, custom_id="settings_logs"),
                Button(label="결제 설정", style=discord.ButtonStyle.success, custom_id="settings_payment"),
            ),
        )

        async def interaction_check(self, i: discord.Interaction) -> bool:
            cid = i.data.get("custom_id")

            if cid == "settings_logs":
                class LogConfigModal(Modal, title="로그 채널 설정"):
                    def __init__(self):
                        super().__init__()
                        c = load_config().get("discord", {}).get("log_channels", {})
                        self.ch = TextInput(label="충전 로그", default=str(c.get("charge") or ""))
                        self.auto_ch = TextInput(label="자동충전 로그", default=str(c.get("auto_charge") or ""))
                        self.bo = TextInput(label="부스트 로그", default=str(c.get("boost") or ""))
                        self.pu = TextInput(label="구매 로그", default=str(c.get("purchase") or ""))
                        self.re = TextInput(label="후기 로그", default=str(c.get("review") or ""))
                        for item in [self.ch, self.auto_ch, self.bo, self.pu, self.re]: self.add_item(item)

                    async def on_submit(self, ii: discord.Interaction):
                        c = load_config()
                        prev = c.get("discord", {}).get("log_channels", {})
                        c["discord"]["log_channels"] = {
                            "charge": self.ch.value, "auto_charge": self.auto_ch.value,
                            "boost": self.bo.value, "purchase": self.pu.value, "review": self.re.value,
                            "general": prev.get("general", ""),
                        }
                        if save_config(c):
                            await ii.response.send_message(view=result_layout("✅ 로그 채널이 설정되었습니다."), ephemeral=True)

                await i.response.send_modal(LogConfigModal())

            elif cid == "settings_payment":
                class PaymentConfigModal(Modal, title="결제 설정"):
                    def __init__(self):
                        super().__init__()
                        c = load_config().get("payment", {})
                        self.bank = TextInput(label="은행명", default=c.get("bank_name", ""))
                        self.acc = TextInput(label="계좌번호", default=c.get("account_number", ""))
                        self.holder = TextInput(label="예금주", default=c.get("account_holder", ""))
                        for item in [self.bank, self.acc, self.holder]: self.add_item(item)

                    async def on_submit(self, ii: discord.Interaction):
                        c = load_config()
                        c["payment"].update({"bank_name": self.bank.value, "account_number": self.acc.value, "account_holder": self.holder.value})
                        if save_config(c):
                            await ii.response.send_message(view=result_layout("✅ 결제 설정이 저장되었습니다."), ephemeral=True)

                await i.response.send_modal(PaymentConfigModal())

            return True

    await interaction.response.send_message(view=SettingsLayout(), ephemeral=True)

@bot.tree.command(name="후기", description="최근 후기를 확인합니다.")
async def reviews(interaction: discord.Interaction):
    revs = get_reviews(5)
    if not revs:
        return await interaction.response.send_message(view=result_layout("등록된 후기가 없습니다."), ephemeral=True)
    lines = ["**# ⭐ 최근 후기**\n"]
    for r in revs:
        lines.append(f"**평점:** {'⭐' * r['rating']}\n{r['content'][:500]}\n")
    text = "\n".join(lines)[:1500]
    await interaction.response.send_message(view=result_layout(text))

@bot.tree.command(name="수동충전", description="사용자의 잔액을 수동으로 충전합니다.")
async def manual_charge(interaction: discord.Interaction, 유저: discord.User, 금액: int):
    if not check_permission(interaction.user.id, interaction.guild.get_member(interaction.user.id)):
        return await interaction.response.send_message(view=result_layout("❌ 권한이 없습니다."), ephemeral=True)
    if add_user_balance(유저.id, 금액):
        log_emb = discord.Embed(title="💰 수동 충전 완료", description=f"**대상:** {유저.mention}\n**금액:** {금액:,}원", color=0x00ff00)
        await send_log("charge", log_emb)
        await interaction.response.send_message(view=result_layout(f"✅ {유저.mention}님께 {금액:,}원이 충전되었습니다."), ephemeral=True)
    else:
        await interaction.response.send_message(view=result_layout("❌ 충전 처리에 실패했습니다."), ephemeral=True)

@bot.tree.command(name="유저정보조회", description="특정 유저의 정보를 조회합니다.")
async def user_info(interaction: discord.Interaction, 유저: discord.User):
    if not check_permission(interaction.user.id, interaction.guild.get_member(interaction.user.id)):
        return await interaction.response.send_message(view=result_layout("❌ 권한이 없습니다."), ephemeral=True)
    balance = get_user_balance(유저.id)
    text = f"**# 👤 {유저.name} 정보**\n\n**잔액:** {balance:,}원"
    await interaction.response.send_message(view=result_layout(text), ephemeral=True)

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user}'); bot.add_view(PanelLayout()); await bot.tree.sync()

@bot.event
async def on_interaction(interaction: discord.Interaction):
    if interaction.type == discord.InteractionType.component and interaction.data.get("custom_id") == "btn_write_review_dm":
        await interaction.response.send_modal(ReviewModal())

async def dm_charge_complete(user_id: int, depositor: str, amount: int, balance: int):
    """자동충전 완료 시 유저에게 DM으로 충전완료 안내 (LayoutView 컨테이너)."""
    try:
        user = bot.get_user(user_id) or await bot.fetch_user(user_id)
        text = f"**# 충전완료**\n\n**입금자명:** {depositor}\n**충전 금액:** {amount:,}원\n**현재 잔액:** {balance:,}원"
        await user.send(view=result_layout(text))
    except Exception:
        pass


class RechargeModal(Modal, title="충전 신청"):
    name, amount = TextInput(label="입금자명", required=True), TextInput(label="충전 금액", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            amt = int(self.amount.value.replace(",", ""))
        except Exception:
            await interaction.response.send_message(view=result_layout("❌ 올바른 금액을 입력해주세요."), ephemeral=True)
            return
        c = load_config()
        p = c.get("payment", {})
        dm_text = (
            f"**# 입금 안내**\n\n"
            f"**입금자명:** {self.name.value}\n**금액:** {amt:,}원\n\n"
            f"**은행:** {p.get('bank_name', '') or '-'}\n**계좌:** {p.get('account_number', '') or '-'}\n**예금주:** {p.get('account_holder', '') or '-'}"
        )
        try:
            await interaction.user.send(view=result_layout(dm_text))
        except Exception:
            await interaction.response.send_message(view=result_layout("❌ DM을 보낼 수 없습니다. DM 설정을 확인해주세요."), ephemeral=True)
            return
        await interaction.response.send_message(view=result_layout("입금 안내를 DM으로 보냈습니다."), ephemeral=True)
        await send_log("charge", discord.Embed(title="💰 충전 신청", description=f"**신청자:** {interaction.user.mention}\n**입금자:** {self.name.value}\n**금액:** {amt:,}원", color=0x8b5cf6))
        save_pending_charge(interaction.user.id, self.name.value, amt, 0, 0)

def start_bot():
    c = load_config(); token = c.get("discord", {}).get("token")
    if token: bot.run(token)

if __name__ == "__main__": start_bot()
