import asyncio
import re
import threading
import uvicorn
import yaml
import os
import logging
from logger import info, fail
from fastapi import FastAPI, Request

logging.getLogger("discord").setLevel(logging.ERROR)
logging.getLogger("uvicorn").setLevel(logging.ERROR)

def load_config():
    try:
        with open('config/config.yaml', 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except Exception:
        return {}

def start_discord_bot():
    try:
        import bot
        bot.start_bot()
    except Exception as e:
        fail(f"Discord Bot 실행 오류: {e}")

app = FastAPI(title="BoostBot Auto-Charge API", version="1.0.0")

def get_auto_charge_token():
    try:
        c = load_config()
        return c.get("extras", {}).get("auto_charge_token") or c.get("payment", {}).get("auto_charge_token")
    except Exception:
        return None

def _parse_deposit_message(message: str):
    text = str(message or "").replace("\r\n", "\n").strip()
    if not text:
        return None, None
    patterns = [
        (r"입금\s*([0-9,]+)원[\s\S]*\n([가-힣A-Za-z0-9]+)\s*$", 1, 2),
        (r"입금\s*([0-9,]+)원\s*([가-힣A-Za-z0-9]+)\s*$", 1, 2),
        (r"([가-힣A-Za-z0-9]+)\s*([0-9,]+)원\s*입금", 2, 1),
        (r"입금\s*([0-9,]+)원.*?\s([가-힣A-Za-z0-9]+)\s*$", 1, 2),
    ]
    for pattern, amount_idx, name_idx in patterns:
        match = re.search(pattern, text)
        if match:
            amount = match.group(amount_idx)
            name = match.group(name_idx)
            return name, amount
    amount_match = re.search(r"입금\s*([0-9,]+)원", text)
    if amount_match:
        amount = amount_match.group(1)
        tokens = re.findall(r"[가-힣A-Za-z0-9]+", text)
        blacklist = {"카카오뱅크", "Web발신", "발신", "입금"}
        name = None
        for token in reversed(tokens):
            if token not in blacklist:
                name = token
                break
        if name:
            return name, amount
    return None, None

async def edit_charge_request_message(channel_id: int, message_id: int, depositor: str, amount: int, balance: int):
    import bot
    channel = bot.bot.get_channel(channel_id)
    if not channel:
        channel = await bot.bot.fetch_channel(channel_id)
    msg = await channel.fetch_message(message_id)
    view = bot.build_charge_completed_view(depositor, amount, balance)
    await msg.edit(embed=None, content=None, view=view)

@app.post("/auto-charge")
async def auto_charge(request: Request):
    try:
        try:
            payload = await request.json()
        except Exception:
            payload = {}
        if not isinstance(payload, dict):
            return {"ok": False, "error": "invalid payload"}

        name = str(payload.get("name", "")).strip()
        raw_amount = payload.get("amount", 0)
        message = payload.get("message") or payload.get("msg") or ""
        if isinstance(raw_amount, str):
            raw_amount = str(raw_amount).replace(",", "").strip()
        if (not name or not raw_amount) and message:
            parsed_name, parsed_amount = _parse_deposit_message(str(message))
            if not name and parsed_name:
                name = parsed_name
            if not raw_amount and parsed_amount:
                raw_amount = str(parsed_amount).replace(",", "").strip()
        amount = int(raw_amount)

        token = payload.get("token")
        if not token:
            auth = request.headers.get("authorization", "")
            if auth.lower().startswith("bearer "):
                token = auth.split(" ", 1)[1].strip()
            elif auth:
                token = auth.strip()
        if not token:
            token = request.headers.get("x-api-key") or request.headers.get("x-server-key")
    except Exception:
        return {"ok": False, "error": "invalid payload"}

    if not name or amount <= 0:
        return {"ok": False, "error": "name/amount required"}

    required_token = get_auto_charge_token()
    if required_token and token != required_token:
        return {"ok": False, "error": "invalid token"}

    import bot
    match = bot.find_pending_charge(name, amount)
    if not match:
        return {"ok": False, "error": "no pending charge"}

    pending_id, user_id, depositor, amt, req_channel_id, req_message_id = match
    try:
        bot.add_user_balance(user_id, amt)
        new_bal = bot.get_user_balance(user_id)
        bot.mark_pending_charge_done(pending_id)

        import discord
        loop = bot.bot.loop

        async def finish():
            if req_channel_id and req_message_id:
                await edit_charge_request_message(req_channel_id, req_message_id, depositor, amt, new_bal)
            else:
                await bot.dm_charge_complete(user_id, depositor, amt, new_bal)
            embed = discord.Embed(title="자동충전 완료", color=0x2b2d31)
            embed.add_field(name="유저", value=f"<@{user_id}> ({user_id})", inline=False)
            embed.add_field(name="입금자명", value=depositor, inline=True)
            embed.add_field(name="충전 금액", value=f"{amt:,}원", inline=True)
            embed.add_field(name="현재 잔액", value=f"{new_bal:,}원", inline=True)
            await bot.send_log("auto_charge", embed)

        future = asyncio.run_coroutine_threadsafe(finish(), loop)
        future.result(timeout=10)

        return {"ok": True, "user_id": user_id, "amount": amt, "balance": new_bal}
    except Exception as e:
        return {"ok": False, "error": "charge failed", "detail": str(e)}

# ---
banner = """
               ██████╗  ██████╗  ██████╗ ███████╗████████╗    ██████╗  ██████╗ ████████╗
               ██╔══██╗██╔═══██╗██╔═══██╗██╔════╝╚══██╔══╝    ██╔══██╗██╔═══██╗╚══██╔══╝
               ██████╔╝██║   ██║██║   ██║███████╗   ██║       ██████╔╝██║   ██║   ██║
               ██╔══██╗██║   ██║██║   ██║╚════██║   ██║       ██╔══██╗██║   ██║   ██║
               ██████╔╝╚██████╔╝╚██████╔╝███████║   ██║       ██████╔╝╚██████╔╝   ██║
               ╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝   ╚═╝       ╚═════╝  ╚═════╝    ╚═╝
                    DK BOOST SYSTEM                          - dk_boost.py
"""

def main():
    config_data = load_config()
    port = config_data.get("extras", {}).get("port", 8000)
    token = config_data.get("discord", {}).get("token")

    print(banner)

    if not token:
        fail("봇 토큰이 설정되지 않았습니다. config/config.yaml을 확인해주세요.")
        return

    bot_thread = threading.Thread(target=start_discord_bot)
    bot_thread.daemon = True
    bot_thread.start()

    try:
        info(f"API 서버를 {port} 포트에서 시작합니다. (자동충전: POST /auto-charge)")
        uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")
    except Exception as e:
        fail(f"API 서버 실행 오류: {e}")

if __name__ == "__main__":
    main()
